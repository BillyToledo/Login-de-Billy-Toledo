<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contenido</title>
</head>
<body>
	<div>
		<h1>Gracias por crear tu cuenta y elegirnos!</h1>
		<a href="cerrar.php">Cerrar sesión</a>

		<div>
			<article>
				<p>Ya iniciaste la sesión, felicidades!</p>

			</article>
		</div>
	</div>
</body>
</html>